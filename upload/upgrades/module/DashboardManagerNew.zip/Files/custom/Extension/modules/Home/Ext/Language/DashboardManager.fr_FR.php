<?php

//Dashboard Manager
$mod_strings['LBL_ADMIN_VERSION_FAIL'] = 'Le gestionnaire de page d&#39;accueil n&#39;est pas compatible avec votre version de SugarCRM et a été désactivé. Veuillez vous vérifier sur SugarForge si une mise à jour n&#39;est pas disponible.';
$mod_strings['LBL_CONFIRM_RESTORE'] = 'Etes-vous sur de vouloir restaurer votre page d&#39;accueil par défaut ?';
$mod_strings['LBL_RESTORE_LINK_TEXT'] = 'Restaurer ma page d&#39;accueil';
