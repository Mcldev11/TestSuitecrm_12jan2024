<?php
 // created: 2012-08-23 23:17:02
$layout_defs["dash_DashboardManager"]["subpanel_setup"]['dash_dashboardmanager_users'] = array (
  'order' => 100,
  'module' => 'Users',
  'subpanel_name' => 'default',
  'sort_order' => 'asc',
  'sort_by' => 'id',
  'title_key' => 'LBL_DASH_DASHBOARDMANAGER_USERS_FROM_USERS_TITLE',
  'get_subpanel_data' => 'dash_dashboardmanager_users',
  'top_buttons' => 
  array (
    0 =>
    array (
      'widget_class' => 'SubPanelTopSelectButton',
      'mode' => 'MultiSelect',
    ),
  ),
);
