<?php
// created: 2012-08-23 23:17:02
$dictionary["dash_DashboardManager"]["fields"]["dash_dashboardbackups_dash_dashboardmanager"] = array (
  'name' => 'dash_dashboardbackups_dash_dashboardmanager',
  'type' => 'link',
  'relationship' => 'dash_dashboardbackups_dash_dashboardmanager',
  'source' => 'non-db',
  'side' => 'right',
  'vname' => 'LBL_DASH_DASHBOARDBACKUPS_DASH_DASHBOARDMANAGER_FROM_DASH_DASHBOARDBACKUPS_TITLE',
);
