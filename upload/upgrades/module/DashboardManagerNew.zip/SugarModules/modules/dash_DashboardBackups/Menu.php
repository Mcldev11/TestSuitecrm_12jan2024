<?php

    $module_menu[]=Array("index.php?module=dash_DashboardManager&action=EditView", $mod_strings['LNK_CREATE_DASHBOARD_TEMPLATE'], "");
    $module_menu[]=Array("index.php?module=dash_DashboardManager&action=ListView", $mod_strings['LNK_VIEW_DASHBOARD_TEMPLATES'], "");

    $module_menu[]=Array("index.php?module=dash_DashboardBackups&action=EditView", $mod_strings['LNK_NEW_RECORD'], "");
    $module_menu[]=Array("index.php?module=dash_DashboardBackups&action=ListView", $mod_strings['LNK_LIST'], "");

?>